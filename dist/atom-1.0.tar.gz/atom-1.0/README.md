# atom

Acoustic travel-time tomography is a remote sensing technology that infers fluctuating fields of velocity and temperature within a sensor network through the travel times of acoustic signals.

## Getting Started

download the code repository from github: https://github.com/NREL/ATom
perform local editable installation: `pip install -e .'


## Authors

Nicholas Hamilton
nicholas.hamilton@nrel.gov

Emina Maric
emina.maric@nrel.gov