from dataclasses import dataclass


@dataclass
class Constants:
    gamma: float  # cfg.constants.gamma
    Ra: float  # cfg.constants.Ra
